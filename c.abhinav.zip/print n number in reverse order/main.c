#include <stdio.h>


void rec(int x);

int main()
{
    rec(69);
    return 0;
}

void rec(int x)
{
    printf("%d,", x);
    if (x <= 1)
        return;
    rec(x - 1); 
}
