#include<stdio.h>
int main()
{ 
  int n=10;
  int x=n++;
  printf("the value of n =%d\n");
  int y=++n;
  printf("the value of x=%d\n",x);
  printf("the value of y=%d\n",y);
  return 0;
}