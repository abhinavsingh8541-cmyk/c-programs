#include <stdio.h>

int main() {
    float bs, da, ta, hra, ts;

   
    printf("Enter Basic Salary: ");
    scanf("%f", &bs);

    
    if (bs < 35000) {
        da = 0.03 * bs;
        ta = 0.12 * bs;
        hra = 0.04 * bs;
    } 
    else if (bs >= 35000 && bs <= 80000) {
        da = 0.04 * bs;
        ta = 0.15 * bs;
        hra = 0.05 * bs;
    } 
    else {  
        da = 0.05 * bs;
        ta = 0.04 * bs;
        hra = 0.07 * bs;
    }

 
    ts = bs + da + ta + hra;

    
    printf("\n--- Salary Breakdown ---\n");
    printf("Basic Salary : %.2f\n", bs);
    printf("DA           : %.2f\n", da);
    printf("TA           : %.2f\n", ta);
    printf("HRA          : %.2f\n", hra);
    printf("Total Salary : %.2f\n", ts);

    return 0;
}
