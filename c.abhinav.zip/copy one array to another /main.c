#include <stdio.h>

int main() {
    int n, a[100], b[100];

    printf("Enter size of array: ");
    scanf("%d", &n);

    printf("Enter %d elements for Array A:\n", n);
    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for(int i = 0; i < n; i++)
        b[i] = a[i];

    printf("Elements copied to Array B:\n");
    for(int i = 0; i < n; i++)
        printf("%d ", b[i]);
    printf("\n");

    return 0;
}

