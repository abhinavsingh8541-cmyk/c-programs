#include <stdio.h>

int sumMatrix(int a[][100], int r, int c) {
    if(r == 0)
        return 0;

    int rowSum = 0;
    for(int j = 0; j < c; j++)
        rowSum += a[r - 1][j];

    return rowSum + sumMatrix(a, r - 1, c);
}

int main() {
    int r, c, a[100][100];

    printf("Enter number of rows: ");
    scanf("%d", &r);

    printf("Enter number of columns: ");
    scanf("%d", &c);

    printf("Enter matrix elements:\n");
    for(int i = 0; i < r; i++)
        for(int j = 0; j < c; j++)
            scanf("%d", &a[i][j]);

    int sum = sumMatrix(a, r, c);

    printf("Sum of all matrix elements (recursion) = %d\n", sum);

    return 0;
}
