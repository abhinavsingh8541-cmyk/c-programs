#include <stdio.h>
int main()
{
    float c_marks, GenAI_marks, sum;
    printf("enter the marks of subject\n");
    scanf("%f%f", &c_marks, &GenAI_marks);

    sum = (30.0/100.0)*c_marks + (70.0/100.0)*GenAI_marks;

    printf("the sum of %f and %f = %f", c_marks, GenAI_marks, sum);
    return 0;
}
