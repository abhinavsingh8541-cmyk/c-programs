#include <stdio.h>

int main() {
int num, first, last;

printf("Enter a number: ");
scanf("%d", &num);

last = num % 10;  // Get last digit

first = num;
while (first >= 10) {
    first = first / 10;
}

printf("First digit: %d\n", first);
printf("Last digit: %d\n", last);

return 0;
}