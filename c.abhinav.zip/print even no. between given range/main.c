#include <stdio.h>

int main() {
    int spoint = 10;
    int epoint = 20;
    int even;
    while (spoint <epoint) { 
        even = spoint % 2;  
        if (even == 0) {
            printf("even number: %d\n", spoint);
        }
        spoint++;  
    }

    return 0;
}