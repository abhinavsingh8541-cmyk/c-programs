#include <stdio.h>

int main() {
    int n, a[100];
    int pos = 0, neg = 0;

    printf("Enter size of array: ");
    scanf("%d", &n);

    printf("Enter %d elements (positive/negative):\n", n);
    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for(int i = 0; i < n; i++) {
        if(a[i] > 0)
            pos++;
        else if(a[i] < 0)
            neg++;
    }

    printf("Count of positive numbers = %d\n", pos);
    printf("Count of negative numbers = %d\n", neg);

    return 0;
}
