
#include <stdio.h>

int main()
{
   printf("hello shoolini"); 

    return 0;
}
