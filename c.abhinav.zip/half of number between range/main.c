#include <stdio.h>

int main() {
    int spoint = 10;
    int epoint = 20;
    int half= (spoint+epoint)/2;

    while (spoint !=half) {
       
            printf("Number:%d\n", spoint);
        
        spoint++;
    }

    return 0;
}

