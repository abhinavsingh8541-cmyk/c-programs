#include <stdio.h>

int main() {
    int maxsize = 100;
    int a[maxsize];
    int n, ele, index = -1;

    printf("Enter number of elements (max 100): ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    printf("Enter element to delete: ");
    scanf("%d", &ele);

    for (int i = 0; i < n; i++) {
        if (a[i] == ele) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf("Element not found");
        return 0;
    }

    for (int i = index; i < n - 1; i++) {
        a[i] = a[i + 1];
    }

    n--;

    printf("Array after deletion:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }

    return 0;
}
