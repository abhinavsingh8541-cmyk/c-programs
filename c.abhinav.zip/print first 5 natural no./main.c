#include <stdio.h>

int main() {
    int n = 5, i;
    i = 1;
    while (i <= n) {
        printf("%d", i);
        i++;
    }
    return 0;
}
