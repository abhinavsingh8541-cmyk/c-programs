#include <stdio.h>

void swap(int x, int y)
{
    int temp;
    printf("\nInside function (before swapping) x = %d, y = %d", x, y);
    
    temp = x;
    x = y;
    y = temp;

    printf("\nInside function (after swapping) x = %d, y = %d", x, y);
}

int main()
{
    int a, b;

    printf("Enter the value of a and b: ");
    scanf("%d %d", &a, &b);

    printf("\nIn main (before swapping) a = %d, b = %d", a, b);

    swap(a, b);

    printf("\nIn main (after swapping) a = %d, b = %d\n", a, b);

    return 0;
}
