#include <stdio.h>
int main()
{
    int digit;
    printf("enter any number:");
    scanf("%d",&digit);
    if (digit>0)
    printf("%d is positive\n",digit);
    else if (digit<0)
    printf("%d is negative\n",digit);
    else
    printf("%d is zero");
    return 0;
}
