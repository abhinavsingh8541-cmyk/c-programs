#include <stdio.h>
int main()
{
   int num;
   printf("enter the value of num:");
   scanf("%d",&num);
   if(num%2==0)
   {
       printf("%dis even number",num);
   }
   else{
       printf("%dis not even",num);
   }
    return 0;
}