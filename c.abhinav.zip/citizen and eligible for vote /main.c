/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int citizen;
    int age;

    printf("Enter your citizenship (1 for Indian, 0 for others): ");
    scanf("%d", &citizen);

    printf("Enter your age: ");
    scanf("%d", &age);

    if(citizen == 1) {
        printf("You are an Indian citizen\n");

        if(age >= 18) {
            printf("You are eligible for vote.");
        } else {
            printf("You are not eligible for vote.");
        }
    } else {
        printf("You are not an Indian citizen");
    }

    return 0;
}