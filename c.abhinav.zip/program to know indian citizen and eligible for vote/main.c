#include <stdio.h>

int main() 
{
    char c;
    int age;
    printf("Enter charracter 'I' or 'i' if you are indian citizen:");
    scanf("%c",&c);
    if(c=='I'||c=='i')
{
    printf("great! enter your age:");
    scanf("%d",&age);
    if(age>=18)
    {
        printf("the age is %d and you are eligible for vote",age);

    }

else
{
    printf("you are under age");
}
}
else
{
    printf("you are not indian");
}
    return 0;
}