#include <stdio.h>

int main() {
    int size, i, ele;

    printf("Enter size: ");
    scanf("%d", &size);

    int a[size];

    printf("Enter elements:\n");
    for (i = 0; i < size; i++)
        scanf("%d", &a[i]);

    printf("Enter element to search: ");
    scanf("%d", &ele);

    for (i = 0; i < size; i++) {
        if (a[i] == ele) {
            printf("Element present\n");
            break;
        }
    }

    if (i == size)
        printf("Not present\n");

    return 0;
}
