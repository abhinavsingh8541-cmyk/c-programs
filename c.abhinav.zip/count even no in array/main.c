#include <stdio.h>

int main() {
    int n, a[100], count = 0;

    printf("Enter size of array: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for(int i = 0; i < n; i++)
        if(a[i] % 2 == 0)
            count++;

    printf("Total even numbers = %d\n", count);

    return 0;
}
