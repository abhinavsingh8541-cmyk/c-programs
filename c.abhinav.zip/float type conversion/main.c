#include <stdio.h>
int main()
{
    float f;
    printf("enter any character:");
    scanf("%f",&f);
    int e=(int)f;
    
    printf("the character %f ASCTL vslue is %d",f,e);
    return 0;
    
}