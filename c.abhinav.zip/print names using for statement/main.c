#include <stdio.h>

int main() {
    int j = 1;
    for (int i = 1; i <= 2; i++) {
        printf("shoolini ");
        
        for (j = 1; j <= 2; j++) {
            printf("btechcse ");
            
            for (int k = 1; k <= 2; ) {
                printf("cprog ");
                k++;
            }
        }
    }
    return 0;
}
