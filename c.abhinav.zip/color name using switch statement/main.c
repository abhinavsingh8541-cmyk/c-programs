#include <stdio.h>

int main()
{
    char color; 
    printf("Enter the color letter between a-z:");
    scanf("%c", &color);

    switch (color)
    {
        case 'r':
            printf("red");
            break;
        case 'b':
            printf("black");
            break;
        case 'p':
            printf("pink");
            break;
        case 'o':
            printf("orange");
            break;
        case 'g':
            printf("green");
            break;
        case 'w':
            printf("white");
            break;
        case 'v':
            printf("violet");
            break;
        default:
            printf("Invalid color name");
    }
    return 0;
}

