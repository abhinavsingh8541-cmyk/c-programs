#include<stdio.h>
int main()
{
    char c;
    printf("enter any character");
    scanf("%c",&c);
    if(c=='A'||c=='E'||c=='I'||c=='O'||c=='U')
    printf("vowel");
    else
    printf("consonant");
    return 0;
}