#include <stdio.h>

void printArrayRec(int a[], int index, int n) {
    if(index == n)
        return;

    printf("%d ", a[index]);

    printArrayRec(a, index + 1, n);
}

int main() {
    int n, a[100];

    printf("Enter size of array: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("Array elements are:\n");
    printArrayRec(a, 0, n);
    printf("\n");

    return 0;
}

