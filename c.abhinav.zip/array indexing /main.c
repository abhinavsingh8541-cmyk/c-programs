#include <stdio.h>
#define Maxsize 100;

int main()
{
    int a[10];
    int size, i;

    printf("Enter the number of elements you want to insert: ");
    scanf("%d", &size);

    printf("Enter %d elements into the array", size);
    for (i = 0; i < size; i++) 
        scanf("%d", &a[i]);
        printf("the array element is:");
     for (i = 0; i < size; i++) 
    printf("%d\t",a[i]);
    return 0;
}