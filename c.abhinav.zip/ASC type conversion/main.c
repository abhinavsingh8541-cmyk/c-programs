#include<stdio.h>
int main()
{
    char c;
    printf("enter any character:");
    scanf("%c",&c);
    printf("ASCTL value is %d\n",c);
    
    printf("the character %c\n",c);
    return 0;
}





