
#include <stdio.h>

int main() {
    int num;

    printf("Enter the value of num: ");
    scanf("%d", &num);

    if((num / 2) * 2 == num) {
        printf("%d is an even number.\n", num);
    } else {
        printf("%d is an odd number.\n", num);
    }

    return 0;
}