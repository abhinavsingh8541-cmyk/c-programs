#include<stdio.h>
int main()
{
    int x = 10;
int i = 0;
while(i<=x)
{
    printf("%d",i);
    i++;
}
return 0;
}