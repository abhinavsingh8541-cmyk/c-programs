#include <stdio.h>
int main()
{
    int rows;
    printf("enter the value of row");
    scanf("%d",&rows);
    for(int i=0;i<=rows;i++)
    {
        for(int j=0;j<=i;j++)
        {
            printf("*");
        }
    
    }   
        
    return 0;
}