#include <stdio.h>

int main() {
    int n, a[100], sum = 0;

    printf("Enter size of array: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for(int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    for(int i = 0; i < n; i++) {
        sum += a[i];
    }

    printf("The sum of all array elements = %d\n", sum);

    return 0;
}

